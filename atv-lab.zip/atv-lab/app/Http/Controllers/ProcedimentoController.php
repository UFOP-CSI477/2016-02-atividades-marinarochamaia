<?php

namespace App\Http\Controllers;

use App\Http\Requests\AdicionarProcedimentoRequest;
use App\Http\Requests\EditarProcedimentoRequest;
use App\Procedimento;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;

class ProcedimentoController extends Controller
{
    /**
     * Recupera e lista todos os procedimentos cadastrados na página de acesso geral.
     */
    public function listarGeral()
    {
        $procedimentos = Procedimento::orderBy('nome', 'asc')->get();
        return view('geral.procedimentos')->with('procedimentos', $procedimentos);
    }

    /**
     * Recupera todos os procedimentos para a listagem do adminsitrador
     */
    public function listar()
    {
        $procedimentos = Procedimento::orderBy('nome', 'asc')->get();
        return view('usuario.administrador.procedimento.listar')->with('procedimentos', $procedimentos);
    }

    /**
     * Mostra a página de adição de um procedimento.
     */
    public function showAdicionar()
    {
        return view('usuario.administrador.procedimento.adicionar');
    }

    /**
     * Cria uma nova instância de procedimento na base de dados.
     */
    public function adicionar(AdicionarProcedimentoRequest $request)
    {
        $formulario = Input::all();
        $formulario['usuario_id'] = Auth::id();
        Procedimento::create($formulario);
        session()->flash('mensagem', 'Procedimento criado com sucesso.');
        return redirect()->route('listarProcedimentos');
    }

    /**
     * Mostra a página de edição de um procedimento.
     * @param $procedimento Procedimento Instância do procedimento que será editada.
     */
    public function showEditar($procedimento)
    {
        return view('usuario.administrador.procedimento.editar')->with('procedimento', $procedimento);
    }

    /**
     * Edita uma instância de procedimento no banco de dados.
     */
    public function editar(EditarProcedimentoRequest $request)
    {
        $formulario = Input::all();
        $procedimento = Procedimento::find($formulario['procedimento']);

        $procedimento->nome = $formulario['nome'];
        $procedimento->preco = $formulario['preco'];

        $procedimento->save();

        session()->flash('mensagem', 'Procedimento editado com sucesso.');

        if(Auth::user()->can('administrar')) return redirect()->route('listarProcedimentos');
        else return redirect()->route('listarExames');
    }

    /**
     * Exclui um procedimento se ele não estiver vinculado a nenhum exame.
     * @param $procedimento Procedimento Instância do procedimento que pode ser deletada.
     */
    public function excluir($procedimento)
    {
        $exames = $procedimento->exames;
        if($exames->isEmpty())
        {
            // Se o procedimento não estiver vinculado a nenhum exame, então pode excluir o procedimento
            $procedimento->delete();
            session()->flash('mensagem', 'Procedimento excluído com sucesso.');
        }
        else session()->flash('mensagem', 'Procedimento está vinculado a exames e não pode ser excluído.');

        return redirect()->back();
    }

    /**
     * Mostra a página contendo os dados dos exames por procedimento
     */
    public function relatorio()
    {
        $procedimentos = Procedimento::with('exames')->get();
        return view('usuario.administrador.procedimento.relatorio')->with('procedimentos', $procedimentos);
    }

    public function showEditarOperador($exame)
    {
        $procedimento = $exame->procedimento;
        return view('usuario.operador.exame.editar')->with('procedimento', $procedimento);
    }
}
