<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginPacienteRequest;
use App\Http\Requests\LoginUsuarioRequest;
use App\Paciente;
use App\Usuario;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest', ['except' => 'logout']);
    }



    /**
     * Mostra a página de seleção do tipo do usuário para realizar o login
     */
    public function showSelecaoLogin()
    {
        return view('auth.selecao');
    }

    /**
     * Mostra a página de login para usuários.
     */
    public function showLoginUsuario()
    {
        return view('auth.usuario.login');
    }

    /**
     * Mostra a página de login para pacientes.
     */
    public function showLoginPaciente()
    {
        return view('auth.paciente.login');
    }

    /**
     * Realiza a autenticação de pacientes.
     */
    public function loginPaciente(LoginPacienteRequest $request)
    {
        $formulario = Input::all(); // recupera as entradas do formulário

        $paciente = Paciente::where('login', $formulario['usuario'])->first(); // Recupera o usuário do banco de dados

        if($paciente->senha == $formulario['senha']) // Verifica se a senha é a mesma
        {
            Auth::guard('pacientes')->login($paciente); // Autentica o paciente
            return redirect()->intended(route('homePaciente')); // Redireciona para a página pretendida ou para a página inicial
        }
        else session()->flash('erro', 'A senha não está certa.'); // Informa que a senha não está certa.

        return redirect()->back()->withInput(Input::except('senha')); // Retorna para  a página de login com o usuário já preenchido.
    }

    /**
     * Realiza a autenticação de administradores e operadores.
     */
    public function loginUsuario(LoginUsuarioRequest $request)
    {
        $formulario = Input::all(); // recupera as entradas do formulário

        $usuario = Usuario::where('login', $formulario['usuario'])->first(); // Recupera o usuário do banco de dados

        if($usuario->senha == $formulario['senha']) // Verifica se a senha é a mesma
        {
            Auth::guard('usuarios')->login($usuario); // Autentica o usuário
            return redirect()->intended(route('homeUsuario')); // Redireciona para a página pretendida ou para a página inicial
        }
        else session()->flash('erro', 'A senha não está certa.'); // Informa que a senha não está certa.

        return redirect()->back()->withInput(Input::except('senha')); // Retorna para  a página de login com o usuário já preenchido.
    }
}
