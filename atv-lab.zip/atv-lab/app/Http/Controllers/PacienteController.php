<?php

namespace App\Http\Controllers;

use App\Http\Requests\CadastroPacienteRequest;
use App\Paciente;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;

class PacienteController extends Controller
{
    /**
     * Mostra a página inicial do paciente
     */
    public function home()
    {
        return view('paciente.home');
    }

    /**
     * Mostra a página de cadastro de usuário
     */
    public function showCadastro()
    {
        return view('paciente.cadastro');
    }

    /**
     * Realiza o cadastro do usuário
     * @param CadastroPacienteRequest $request Regras de validação do formulário de cadastro
     */
    public function cadastrar(CadastroPacienteRequest $request)
    {
        $formulario = Input::all();

        $pacientesExiste = Paciente::where('login', $formulario['login'])->get(); // Procura por paciente com o mesmo login
        if(!is_null($pacientesExiste))
        {
            // Se a variavél teve um valor atribuído, então já existe algum paciente com o mesmo nome
            session()->flash('erro', 'Já existe um paciente cadastrado com esse login.');
            return redirect()->back()->withInput(Input::except('login'));
        }
        else
        {
            // Se a variável não foi atribuída com nenhum valor, então não existe nenhum paciente com esse login
            $novoPaciente = Paciente::create(Input::all()); // Cria o paciente no banco
            Auth::guard('pacientes')->login($novoPaciente); // Realiza o login automaticamente
            return redirect()->route('homePaciente');
        }
    }

    /**
     * Exibe o relatório de exames por paciente.
     */
    public function relatorio()
    {
        $pacientes = Paciente::with('exames', 'exames.procedimento')->get();
        return view('usuario.administrador.paciente.relatorio')->with('pacientes', $pacientes);
    }
}
