<?php

namespace App\Http\Controllers;

use App\Exame;
use App\Http\Requests\SolicitarExameRequest;
use App\Procedimento;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;

class ExameController extends Controller
{
    /**
     * Mostra a lista de exames vinculados ao usuário que está autenticado no momento
     */
    public function listar()
    {
        $exames = Exame::with('procedimento')->where('paciente_id', Auth::id())->get();
        $exames->sortBy('procedimento.nome');
        $exames->sortByDesc('data');

        $precoTotal = 0;
        $quantidadeExames = 0;

        foreach($exames as $exame)
        {
            $precoTotal += $exame->procedimento->preco;
            ++$quantidadeExames;
        }

        return view('paciente.exame.listar')->with(['exames' => $exames, 'precoTotal' => $precoTotal, 'quantidadeExames' => $quantidadeExames]);
    }

    /**
     * Exibe a páginda para solicitação de um exame.
     */
    public function showSolicitar()
    {
        $procedimentos = Procedimento::all();
        return view('paciente.exame.solicitar')->with('procedimentos', $procedimentos);
    }

    /**
     * Armazena uma nova instância de exame no banco de dados.
     */
    public function solicitar(SolicitarExameRequest $request)
    {
        $formulario = Input::all();
        $exame = Exame::create(['paciente_id' => Auth::id(), 'procedimento_id' => $formulario['procedimento'], 'data' => $formulario['data']]);
        return redirect()->route('listarExamesPaciente');
    }

    /**
     * Remove uma instância de Exame do banco de dados
     * @param $exame Exame Instância de um exame que será deletado.
     */
    public function excluir($exame)
    {
        $exame->delete();
        session()->flash('mensagem', 'Exame excluído com sucesso.');
        return redirect()->back();
    }

    /**
     * Mostra a página de edição de um exame
     * @param $id ID do exame a ser editado
     */
    public function showEditar($exame)
    {
        $procedimentos = Procedimento::all();
        return view('paciente.exame.editar')->with(['procedimentos' => $procedimentos, 'exame' => $exame]);
    }

    /**
     * Edita uma instância de exame no banco de dados.
     */
    public function editar()
    {
        $formulario = Input::all();
        $exame = Exame::find($formulario['exame']);

        if (Auth::user()->can('manipular-exame', $exame)) {
            $exame->procedimento_id = $formulario['procedimento'];
            $exame->data = $formulario['data'];
            $exame->save();

            session()->flash('mensagem', 'Exame editado com sucesso.');
            return redirect()->route('listarExamesPaciente');
        }
        else return abort(403);
    }

    /**
     * Lista todos os exames cadastrados
     */
    public function listarTodos()
    {
        $exames = Exame::with('paciente', 'procedimento')->get();
        return view('usuario.administrador.exame.listar')->with('exames', $exames);
    }

}
