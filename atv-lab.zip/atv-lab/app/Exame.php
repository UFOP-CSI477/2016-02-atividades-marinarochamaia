<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Exame extends Model
{
    public $timestamps = false;

    protected $fillable = [
      'paciente_id', 'procedimento_id', 'data',
    ];

    /**
     * Recupera o paciente vinculado ao exame.
     */
    public function paciente() {
        return $this->belongsTo('App\Paciente');
    }

    /**
     * Recupera o procedimento vinculado ao exame
     */
    public function procedimento()
    {
        return $this->belongsTo('App\Procedimento');
    }
}
