<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Login</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('loginPaciente')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('usuario') ? ' has-error' : ''); ?>">
                            <label for="usuario" class="col-md-4 control-label">Usuario</label>

                            <div class="col-md-6">
                                <input id="usuario" type="text" class="form-control" maxlength="20" name="usuario" value="<?php echo e(old('usuario')); ?>" required <?php if($errors->has('usuario')): ?> autofocus <?php endif; ?>>

                                <?php if($errors->has('usuario')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('usuario')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('senha') || session()->has('erro') ? ' has-error' : ''); ?>">
                            <label for="senha" class="col-md-4 control-label">Senha</label>

                            <div class="col-md-6">
                                <input id="senha" type="password" class="form-control" name="senha" maxlength="10" required <?php if(session()->has('erro')): ?> autofocus <?php endif; ?>>

                                <?php if($errors->has('senha') || session()->has('erro')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('senha')); ?> <?php echo e(session('erro')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-sign-in"></i> Login
                                </button>

                                <a class="btn btn-link" href="<?php echo e(route('showCadastroPaciente')); ?>">
                                    <i class="fa fa-user-plus"></i> Cadastre-se
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>