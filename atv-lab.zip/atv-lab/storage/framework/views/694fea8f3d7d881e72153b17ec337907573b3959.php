<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Área do Usuário</div>
                    <div class="panel-body text-center">
                        <?php if(session()->has('mensagem')): ?>
                            <div class="alert alert-info text-center">
                                <?php echo session('mensagem'); ?>

                            </div>
                            <br />
                        <?php endif; ?>
                        <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('administrar')): ?>
                            <a class="btn btn-default" role="button" href="<?php echo e(route('showAdicionarProcredimento')); ?>"><i class="fa fa-plus fa-2x"></i><br />Adicionar Procedimento</a>
                            <a class="btn btn-default" role="button" href="<?php echo e(route('listarProcedimentos')); ?>"><i class="fa fa-th-list fa-2x"></i><br />Listar Procedimentos</a>
                            <a class="btn btn-default" role="button" href="<?php echo e(route('listarExames')); ?>"><i class="fa fa-th-list fa-2x"></i><br />Listar Exames</a>
                            <a class="btn btn-default" role="button" href="<?php echo e(route('relatorioPacientes')); ?>"><i class="fa fa-pie-chart fa-2x"></i><br />Relatório/Lista por Pacientes</a>
                            <a class="btn btn-default" role="button" href="<?php echo e(route('relatorioProcedimento')); ?>"><i class="fa fa-pie-chart fa-2x"></i><br />Relatório/Lista por Procedimentos</a>
                        <?php endif; ?>
                        <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('operar')): ?>
                            <a class="btn btn-default" role="button" href="<?php echo e(route('listarExames')); ?>"><i class="fa fa-th-list fa-2x"></i><br />Listar Exames</a>
                        <?php endif; ?>
                        <a class="btn btn-default" role="button" href="<?php echo e(route('logout')); ?>"><i class="fa fa-sign-out fa-2x"></i><br />Sair</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>