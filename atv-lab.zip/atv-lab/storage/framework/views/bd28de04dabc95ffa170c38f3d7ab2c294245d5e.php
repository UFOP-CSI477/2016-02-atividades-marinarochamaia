<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Novo Paciente</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('cadastroPaciente')); ?>">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group<?php echo e($errors->has('nome') ? ' has-error' : ''); ?>">
                                <label for="login" class="col-md-4 control-label">Nome</label>

                                <div class="col-md-6">
                                    <input id="nome" type="text" class="form-control" maxlength="45" name="nome" value="<?php echo e(old('nome')); ?>" required autofocus>

                                    <?php if($errors->has('nome')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('nome')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('login') || session()->has('erro') ? ' has-error' : ''); ?>">
                                <label for="login" class="col-md-4 control-label">Login</label>

                                <div class="col-md-6">
                                    <input id="login" type="text" class="form-control" maxlength="20" name="login" value="<?php echo e(old('login')); ?>" required <?php if($errors->has('login')): ?> autofocus <?php endif; ?>>

                                    <?php if($errors->has('login') || session()->has('erro')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('login')); ?> <?php echo e(session('erro')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('senha') ? ' has-error' : ''); ?>">
                                <label for="senha" class="col-md-4 control-label">Senha</label>

                                <div class="col-md-6">
                                    <div class="input-group">
                                        <input id="senha" type="password" class="form-control" name="senha" maxlength="10" required <?php if(session()->has('erro')): ?> autofocus <?php endif; ?>>
                                        <span class="input-group-btn">
                                            <button class="btn btn-default" type="button"><i class="fa fa-eye"></i></button>
                                        </span>
                                    </div>

                                    <?php if($errors->has('senha') || session()->has('erro')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('senha')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-groupr">
                                <div class="col-md-8 col-md-offset-4 text-cente">
                                    <button class="btn btn-default" onclick="history.back()">
                                        <i class="fa fa-arrow-left"></i> Voltar
                                    </button>
                                    <button type="reset" class="btn btn-warning">
                                        <i class="fa fa-eraser"></i> Limpar
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-user-plus"></i> Cadastrar
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('extra-scripts'); ?>
<script>
    $('.input-group-btn').hover(function () {
        $('#senha').attr('type', 'text');
    }, function () {
        $('#senha').attr('type', 'password');
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>