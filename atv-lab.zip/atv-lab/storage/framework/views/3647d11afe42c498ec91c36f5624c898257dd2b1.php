<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Administrador - Lista de Procedimentos</div>
                    <div class="panel-body">
                        <?php if(session()->has('mensagem')): ?>
                            <div class="alert alert-info text-center">
                                <?php echo session('mensagem'); ?>

                            </div>
                            <br />
                        <?php endif; ?>
                        <table class="table table-responsive table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Preço</th>
                                <th>Ações</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $procedimentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procedimento): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td><?php echo $procedimento->nome; ?></td>
                                    <td>R$ <?php echo $procedimento->preco; ?></td>
                                    <td>
                                        <a class="btn btn-primary" role="button" href="<?php echo e(route('showEditarProcedimento', $procedimento->id)); ?>"><i class="fa fa-pencil-square-o"></i> Editar</a>
                                        ou
                                        <a class="btn btn-danger" role="button" href="<?php echo e(route('excluirProcedimento', $procedimento->id)); ?>"><i class="fa fa-times"></i> Excluir</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>
                        </table>
                        <button class="btn btn-default" onclick="history.back()"><i class="fa fa-arrow-left"></i> Voltar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>