<?php $__env->startPush('extra-css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('extra-scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/locales/bootstrap-datepicker.pt-BR.min.js"></script>
<script>
    $('.datepicker').datepicker({
        language: 'pt-BR',
        startDate: "'" + new Date().getDate() + "'"
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Editar Exame</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('editarExame')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="exame" value="<?php echo e($exame->id); ?>">

                            <div class="form-group<?php echo e($errors->has('procedimento') ? ' has-error' : ''); ?>">
                                <label for="procedimento" class="col-md-4 control-label">Procedimento</label>

                                <div class="col-md-6">
                                    <select id="procedimento" class="form-control" name="procedimento" required autofocus>
                                        <option value="">Selecione o procedimento</option>
                                        <?php $__currentLoopData = $procedimentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procedimento): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo $procedimento->id; ?>" <?php if($exame->procedimento_id == $procedimento->id): ?> selected <?php endif; ?>><?php echo $procedimento->nome; ?> - R$<?php echo $procedimento->preco; ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>

                                    <?php if($errors->has('procedimento')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('procedimento')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('data') ? ' has-error' : ''); ?>">
                                <label for="data" class="col-md-4 control-label">Data</label>

                                <div class="col-md-6">
                                    <input id="data" type="text" data-date-format="dd/mm/yyyy" class="datepicker form-control" maxlength="10" name="data" value="<?php echo $exame->data; ?>" required <?php if($errors->has('data')): ?> autofocus <?php endif; ?>>

                                    <?php if($errors->has('data') || session()->has('erro')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('data')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-groupr">
                                <div class="col-md-8 col-md-offset-4 text-cente">
                                    <button class="btn btn-default" onclick="history.back()">
                                        <i class="fa fa-arrow-left"></i> Voltar
                                    </button>
                                    <button type="reset" class="btn btn-warning">
                                        <i class="fa fa-eraser"></i> Limpar
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-edit"></i> Editar
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>