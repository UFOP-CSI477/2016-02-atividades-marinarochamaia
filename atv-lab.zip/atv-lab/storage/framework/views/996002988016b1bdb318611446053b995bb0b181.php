<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Administrador - Relatório/Lista de Exames por Procedimento</div>
                    <div class="panel-body">
                        <?php if(session()->has('mensagem')): ?>
                            <div class="alert alert-info text-center">
                                <?php echo session('mensagem'); ?>

                            </div>
                            <br />
                        <?php endif; ?>
                        <table class="table table-responsive table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>Quantidade</th>
                                <th>Preço</th>
                                <th>Total</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $procedimentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procedimento): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td><?php echo $procedimento->id; ?></td>
                                    <td><?php echo $procedimento->nome; ?></td>
                                    <td><?php echo $procedimento->exames->count(); ?></td>
                                    <td><?php echo $procedimento->preco; ?></td>
                                    <td><?php echo e($procedimento->exames->count() * $procedimento->preco); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>
                        </table>
                        <button class="btn btn-default" onclick="history.back()"><i class="fa fa-arrow-left"></i> Voltar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>