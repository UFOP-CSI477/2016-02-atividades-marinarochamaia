<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Administrador - Adicionar Procedimento</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('adicionarProcedimento')); ?>">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group<?php echo e($errors->has('nome') ? ' has-error' : ''); ?>">
                                <label for="nome" class="col-md-4 control-label">Nome</label>

                                <div class="col-md-6">
                                    <input id="nome" class="form-control" name="nome" type="text" maxlength="60" required autofocus>


                                    <?php if($errors->has('nome')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('nome')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('preco') ? ' has-error' : ''); ?>">
                                <label for="preco" class="col-md-4 control-label">Preço</label>

                                <div class="col-md-6">
                                    <input id="preco" type="number" step="0.01" class="form-control" min="0" name="preco" required <?php if($errors->has('preco')): ?> autofocus <?php endif; ?>>

                                    <?php if($errors->has('preco')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('preco')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-8 col-md-offset-4">
                                    <button class="btn btn-default" onclick="history.back()">
                                        <i class="fa fa-arrow-left"></i> Voltar
                                    </button>
                                    <button type="reset" class="btn btn-warning">
                                        <i class="fa fa-eraser"></i> Limpar
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-plus"></i> Adicionar
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>