<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Paciente - Lista de Exames</div>
                    <div class="panel-body">
                        <?php if(session()->has('mensagem')): ?>
                            <div class="alert alert-info text-center">
                                <?php echo session('mensagem'); ?>

                            </div>
                            <br />
                        <?php endif; ?>
                        <table class="table table-responsive table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Procedimento</th>
                                <th>Preço</th>
                                <th>Data</th>
                                <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('operar')): ?>
                                    <th>Ação</th>
                                <?php endif; ?>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $exames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exame): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td><?php echo e($exame->id); ?></td>
                                    <td><?php echo $exame->procedimento->nome; ?></td>
                                    <td>R$ <?php echo $exame->procedimento->preco; ?></td>
                                    <td><?php echo $exame->data; ?></td>
                                    <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('operar')): ?>
                                        <td><a class="btn btn-primary" role="button" href="<?php echo e(route('showEditarProcedimentoOperador', $exame->id)); ?>"><i class="fa fa-pencil-square-o"></i> Editar</a></td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>
                        </table>
                        <button class="btn btn-default" onclick="history.back()"><i class="fa fa-arrow-left"></i> Voltar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>