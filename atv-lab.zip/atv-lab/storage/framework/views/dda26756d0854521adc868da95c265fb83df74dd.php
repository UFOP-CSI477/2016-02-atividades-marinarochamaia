<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Paciente - Lista de Exames</div>
                    <div class="panel-body">
                        <?php if(session()->has('mensagem')): ?>
                            <div class="alert alert-info text-center">
                                <?php echo session('mensagem'); ?>

                            </div>
                            <br />
                        <?php endif; ?>
                        <table class="table table-responsive table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>Procedimento</th>
                                <th>Preço</th>
                                <th>Data</th>
                                <th>Ação</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $exames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exame): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td><?php echo $exame->procedimento->nome; ?></td>
                                    <td>R$ <?php echo $exame->procedimento->preco; ?></td>
                                    <td><?php echo $exame->data; ?></td>
                                    <td><a class="btn btn-primary" href="<?php echo e(route('showEditarExame', $exame->id)); ?>"><i class="fa fa-pencil-square-o"></i> Editar</a> ou <a href="<?php echo e(route('excluirExame', $exame->id)); ?>" class="btn btn-danger"><i class="fa fa-times"></i> Excluir</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td><?php echo $quantidadeExames; ?> exame(s)</td>
                                    <td>R$<?php echo $precoTotal; ?></td>
                                    <td>N/A</td>
                                    <td>N/A</td>
                                </tr>
                            </tfoot>
                        </table>
                        <button class="btn btn-default" onclick="history.back()"><i class="fa fa-arrow-left"></i> Voltar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>