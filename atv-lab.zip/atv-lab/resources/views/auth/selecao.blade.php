@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Seleção do tipo de usuário</div>
                    <div class="panel-body text-center">
                        <a class="btn btn-default" role="button" href="{{ route('showLoginPaciente') }}"><i class="fa fa-heartbeat fa-2x"></i><br />Paciente</a>
                        <a class="btn btn-default" role="button" href="{{ route('showLoginUsuario') }}"><i class="fa fa-user-circle-o fa-2x"></i><br />Usuário</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
