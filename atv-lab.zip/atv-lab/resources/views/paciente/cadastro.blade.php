@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Novo Paciente</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" method="POST" action="{{ route('cadastroPaciente') }}">
                            {{ csrf_field() }}

                            <div class="form-group{{ $errors->has('nome') ? ' has-error' : '' }}">
                                <label for="login" class="col-md-4 control-label">Nome</label>

                                <div class="col-md-6">
                                    <input id="nome" type="text" class="form-control" maxlength="45" name="nome" value="{{ old('nome') }}" required autofocus>

                                    @if ($errors->has('nome'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('nome') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('login') || session()->has('erro') ? ' has-error' : '' }}">
                                <label for="login" class="col-md-4 control-label">Login</label>

                                <div class="col-md-6">
                                    <input id="login" type="text" class="form-control" maxlength="20" name="login" value="{{ old('login') }}" required @if($errors->has('login')) autofocus @endif>

                                    @if ($errors->has('login') || session()->has('erro'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('login') }} {{ session('erro') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('senha') ? ' has-error' : '' }}">
                                <label for="senha" class="col-md-4 control-label">Senha</label>

                                <div class="col-md-6">
                                    <div class="input-group">
                                        <input id="senha" type="password" class="form-control" name="senha" maxlength="10" required @if(session()->has('erro')) autofocus @endif>
                                        <span class="input-group-btn">
                                            <button class="btn btn-default" type="button"><i class="fa fa-eye"></i></button>
                                        </span>
                                    </div>

                                    @if ($errors->has('senha') || session()->has('erro'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('senha')}}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-groupr">
                                <div class="col-md-8 col-md-offset-4 text-cente">
                                    <button class="btn btn-default" onclick="history.back()">
                                        <i class="fa fa-arrow-left"></i> Voltar
                                    </button>
                                    <button type="reset" class="btn btn-warning">
                                        <i class="fa fa-eraser"></i> Limpar
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-user-plus"></i> Cadastrar
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('extra-scripts')
<script>
    $('.input-group-btn').hover(function () {
        $('#senha').attr('type', 'text');
    }, function () {
        $('#senha').attr('type', 'password');
    });
</script>
@endpush