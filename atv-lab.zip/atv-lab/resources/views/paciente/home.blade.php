@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading text-center">Área do Paciente</div>
                    <div class="panel-body text-center">
                        @if(session()->has('mensagem'))
                            <div class="alert alert-info text-center">
                                {!! session('mensagem') !!}
                            </div>
                            <br />
                        @endif
                        <a class="btn btn-default" role="button" href="{{ route('showSolicitarExame') }}"><i class="fa fa-heartbeat fa-2x"></i><br />Solicitar Exame</a>
                        <a class="btn btn-default" role="button" href="{{ route('listarExamesPaciente') }}"><i class="fa fa-th-list fa-2x"></i><br />Ver Exames Solicitados</a>
                        <a class="btn btn-default" role="button" href="{{ route('logout') }}"><i class="fa fa-sign-out fa-2x"></i><br />Sair</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
