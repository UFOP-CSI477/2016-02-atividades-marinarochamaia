@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Área do Usuário</div>
                    <div class="panel-body text-center">
                        @if(session()->has('mensagem'))
                            <div class="alert alert-info text-center">
                                {!! session('mensagem') !!}
                            </div>
                            <br />
                        @endif
                        @can('administrar')
                            <a class="btn btn-default" role="button" href="{{ route('showAdicionarProcredimento') }}"><i class="fa fa-plus fa-2x"></i><br />Adicionar Procedimento</a>
                            <a class="btn btn-default" role="button" href="{{ route('listarProcedimentos') }}"><i class="fa fa-th-list fa-2x"></i><br />Listar Procedimentos</a>
                            <a class="btn btn-default" role="button" href="{{ route('listarExames') }}"><i class="fa fa-th-list fa-2x"></i><br />Listar Exames</a>
                            <a class="btn btn-default" role="button" href="{{ route('relatorioPacientes') }}"><i class="fa fa-pie-chart fa-2x"></i><br />Relatório/Lista por Pacientes</a>
                            <a class="btn btn-default" role="button" href="{{ route('relatorioProcedimento') }}"><i class="fa fa-pie-chart fa-2x"></i><br />Relatório/Lista por Procedimentos</a>
                        @endcan
                        @can('operar')
                            <a class="btn btn-default" role="button" href="{{ route('listarExames') }}"><i class="fa fa-th-list fa-2x"></i><br />Listar Exames</a>
                        @endcan
                        <a class="btn btn-default" role="button" href="{{ route('logout') }}"><i class="fa fa-sign-out fa-2x"></i><br />Sair</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
