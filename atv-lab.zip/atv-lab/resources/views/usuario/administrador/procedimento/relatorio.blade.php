@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Administrador - Relatório/Lista de Exames por Procedimento</div>
                    <div class="panel-body">
                        @if(session()->has('mensagem'))
                            <div class="alert alert-info text-center">
                                {!! session('mensagem') !!}
                            </div>
                            <br />
                        @endif
                        <table class="table table-responsive table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>Quantidade</th>
                                <th>Preço</th>
                                <th>Total</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($procedimentos as $procedimento)
                                <tr>
                                    <td>{!! $procedimento->id !!}</td>
                                    <td>{!! $procedimento->nome !!}</td>
                                    <td>{!! $procedimento->exames->count() !!}</td>
                                    <td>{!! $procedimento->preco !!}</td>
                                    <td>{{ $procedimento->exames->count() * $procedimento->preco }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        <button class="btn btn-default" onclick="history.back()"><i class="fa fa-arrow-left"></i> Voltar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
