<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/



// Rotas disponíveis para pacientes autenticados
Route::group(['middleware' => 'auth:pacientes', 'prefix' => 'paciente'], function (){
    Route::get('home', ['as' => 'homePaciente', 'uses' => 'PacienteController@home']);

    // Rotas relacionadas a exames
    Route::group(['prefix' => 'exame'], function(){
        Route::get('listar', ['as' => 'listarExamesPaciente', 'uses' => 'ExameController@listar']);
        Route::get('solicitar', ['as' => 'showSolicitarExame', 'uses' => 'ExameController@showSolicitar']);
        Route::post('solicitar', ['as' => 'solicitarExame', 'uses' => 'ExameController@solicitar']);
        Route::get('editar/{exame}', ['as' => 'showEditarExame', 'uses' => 'ExameController@showEditar'])->middleware('can:manipular-exame,exame');;
        Route::post('editar', ['as' => 'editarExame', 'uses' => 'ExameController@editar']);
        Route::get('excluir/{exame}', ['as' => 'excluirExame', 'uses' => 'ExameController@excluir'])->middleware('can:maniplar-exame,exame');;
    });
});

// Rotas para administradores e operadores autenticados
Route::group(['middleware' => 'auth:usuarios', 'prefix' => 'usuario'], function (){

    // Rotas apenas para administradores
    Route::group(['middleware' => 'can:administrar', 'prefix' => 'administrador'], function (){
        Route::group(['prefix' => 'procedimento'], function(){
            Route::get('listar', ['as' => 'listarProcedimentos', 'uses' => 'ProcedimentoController@listar']);
            Route::get('adicionar', ['as' => 'showAdicionarProcredimento', 'uses' => 'ProcedimentoController@showAdicionar']);
            Route::post('adicionar', ['as' => 'adicionarProcedimento', 'uses' => 'ProcedimentoController@adicionar']);
            Route::get('editar/{procedimento}', ['as' => 'showEditarProcedimento', 'uses' => 'ProcedimentoController@showEditar']);
            Route::get('excluir/{procedimento}', ['as' => 'excluirProcedimento', 'uses' => 'ProcedimentoController@excluir']);
        });

        Route::get('relatorio/paciente', ['as' => 'relatorioPacientes', 'uses' => 'PacienteController@relatorio']);
        Route::get('relatorio/procedimento', ['as' => 'relatorioProcedimento', 'uses' => 'ProcedimentoController@relatorio']);
    });

    // Rotas penas para operadores
    Route::group(['middleware' => 'can:operar', 'prefix' => 'operador'], function(){
        Route::get('procedimento/editar/{exame}', ['as' => 'showEditarProcedimentoOperador', 'uses' => 'ProcedimentoController@showEditarOperador']);
    });

    // Rotas híbridas
    Route::get('home', ['as' => 'homeUsuario', 'uses' => 'UsuarioController@home']);
    Route::get('listar/exame', ['as' => 'listarExames', 'uses' => 'ExameController@listarTodos']);
    Route::post('editar', ['as' => 'editarProcedimento', 'uses' => 'ProcedimentoController@editar']);
});

// Página inicial do sistema
Route::get('/', function () {
    return view('inicio');
});

// Rota que exibe a lista d eprocedimentos
Route::get('geral/procedimentos', ['as' => 'procedimentosAreaGeral', 'uses' => 'ProcedimentoController@listarGeral']);

// Rota para usuários que tentam acessar rotas indevidas e são redirecionados para o login
Route::get('login', ['as' => 'selecaoLogin', 'uses' => 'Auth\LoginController@showSelecaoLogin']);

// Rotas de login para usuário
Route::get('usuario/login', ['as' => 'showLoginUsuario', 'uses' => 'Auth\LoginController@showLoginUsuario']);
Route::post('usuario/login', ['as' => 'loginUsuario', 'uses' => 'Auth\LoginController@loginUsuario']);

// Rotas de login e cadastro para paciente
Route::group(['prefix' => 'paciente'], function() {
    Route::get('login', ['as' => 'showLoginPaciente', 'uses' => 'Auth\LoginController@showLoginPaciente']);
    Route::post('login', ['as' => 'loginPaciente', 'uses' => 'Auth\LoginController@loginPaciente']);
    Route::get('cadastrar', ['as' => 'showCadastroPaciente', 'uses' => 'PacienteController@showCadastro']);
    Route::post('cadastrar', ['as' => 'cadastroPaciente', 'uses' => 'PacienteController@cadastrar']);
});

// Rota para sair do sistema
Route::get('sair', ['as' => 'logout', 'uses' => 'Auth\LoginController@logout']);